<?php
session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['usertype'])) {
    header("location: logout.php");
    exit;
}

include 'db-connect.php';

$rowperpage = 100;
$row = 0;

// // Previous Button
// if(isset($_POST['but_prev'])){
//     $row = $_POST['row'];
//     $row -= $rowperpage;
//     if( $row < 0 ){
//         $row = 0;
//     }
// }

// // Next Button
// if(isset($_POST['but_next'])){
//     $row = $_POST['row'];
//     $allcount = $_POST['allcount'];

//     $val = $row + $rowperpage;
//     if( $val < $allcount ){
//         $row = $val;
//     }
// }

// generating orderby and sort url for table header
function sortorder($fieldname){
    $sorturl = "?order_by=".$fieldname."&sort=";
    $sorttype = "asc";
    if(isset($_GET['order_by']) && $_GET['order_by'] == $fieldname){
        if(isset($_GET['sort']) && $_GET['sort'] == "asc"){
            $sorttype = "desc";
        }
    }
    $sorturl .= $sorttype;
    return $sorturl;
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Emp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    <!-- import index.css -->
    
  </head>
  <style>
    #content{
        border:1px solid darkgrey;
        border-radius:3px;
        padding:5px;
        width: 90%;
        margin: 0 auto;
    }

    /* Table */
    #emp_table {
        border:3px solid lavender;
        border-radius:10px !important;
    }

    /* Table header */

    .tr_header th a{
        color: white;
        text-decoration: none;
    }

    .tr_header{
        background-color:dodgerblue;
    }

    .tr_header th{
        color:white;
        padding:10px 0px;
        letter-spacing: 1px;
    }

    /* Table rows and columns */
    #emp_table td{
        padding:10px;
    }
    #emp_table tr:nth-child(even){
        /* background-color:lavender; */
        color:black;
    }

    /* */
    #div_pagination{
        /* width:100%; */
        margin-top:5px;
        text-align:center;
    }

    .button{
        border-radius:3px;
        border:0px;
        background-color:mediumpurple;
        color:white;
        padding:10px 20px;
        letter-spacing: 1px;
    }
</style>
  <body>
    <!-- include nav.php -->
    <?php include 'nav.php'; ?>
    
    <!-- table -->

    <!-- reload button to refresh table data -->

    <div id="content" class="table-responsive">
        <!-- <div id="div_reload">
            <form method="post" action="">
                <input type="submit" name="but_reload" value="Reload" class="button">
            </form>
        </div> -->
      <table id="emp_table" class="table table-hover table-bordered table-striped">
        <thead align="center">
          <tr class="tr_header">
            <th>Sr. No</th>
            <th><a href="<?php echo sortorder('empid'); ?>" class="sort">Employee ID <i class="fa fa-fw fa-sort"></i></a></th>
            <th><a href="<?php echo sortorder('empname'); ?>" class="sort">Employee Name <i class="fa fa-fw fa-sort"></i></a></th>
            <th><a href="<?php echo sortorder('empage'); ?>" class="sort">Employee Age <i class="fa fa-fw fa-sort"></i></a></th>
            <th><a href="<?php echo sortorder('empsalary'); ?>" class="sort">Employee Salary <i class="fa fa-fw fa-sort"></i></a></th>
            <th><a href="<?php echo sortorder('joiningdate'); ?>" class="sort">Joining Date <i class="fa fa-fw fa-sort"></i></a></th>
            <th>Employee Status</th>
          </tr>
        </thead>
        
        <tbody>
              <!-- <?php echo 'ho';?> -->

                <!-- display employee data from activeemp table with green color row for employee with 5 years -->

                <?php

                  // count total number of rows
                  $sql = "SELECT COUNT(*) AS cntrows FROM activeemp";
                  // $result = mysqli_query($con,$sql);
                  // echo "hii";
                  // $fetchresult = mysqli_fetch_array($result);
                  // $allcount = $fetchresult['cntrows'];

                  // selecting rows
                  $orderby = " ORDER BY empid desc ";
                  if(isset($_GET['order_by']) && isset($_GET['sort'])){
                      $orderby = ' order by '.$_GET['order_by'].' '.$_GET['sort'];
                  }

                  
                  $query = "SELECT * FROM `activeemp`  ".$orderby." limit $row,".$rowperpage;
                  // echo "hii";
                  $result = mysqli_query($conn, $query);
                    $sno = $row + 1;
                    
                    while ($row = mysqli_fetch_array($result)) {
                  // echo "hii";
                        $empid = $row['empid'];
                        $empname = $row['empname'];
                        $empage = $row['empage'];
                        $empsalary = $row['empsalary'];
                        $joiningdate = $row['joiningdate'];
                        $date = date('Y-m-d');
                        $diff = date_diff(date_create($joiningdate), date_create($date));
                        $years = $diff->format('%y');
                        $empstatus = "Inactive";
                        if ($years >= 5) {
                            echo "<tr style='background-color: #00ff95;'>";
                            $empstatus = "Active";
                        } else {
                            echo "<tr>";
                        }
                        echo "<td align='center'>" . $sno . "</td>";
                        echo "<td align='center'>" . $empid . "</td>";
                        echo "<td align='center'>" . $empname . "</td>";
                        echo "<td align='center'>" . $empage . "</td>";
                        echo "<td align='center'>" . $empsalary . "</td>";
                        echo "<td align='center'>" . $joiningdate . "</td>";
                        echo "<td align='center'>" . $empstatus . "</td>";
                        echo "</tr>";
                        $sno ++;
                    }
                
                ?>
            </tbody>

        </table>
        <!-- <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form> -->
    </div>

    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="extensions/natural-sorting/bootstrap-table-natural-sorting.js"></script>
</body>
</html>