<?php
session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['usertype'])) {
    header("location: logout.php");
    exit;
}

if ($_SESSION['usertype'] != 1) {
    header("location: dashboard.php");
    exit;
}

include 'db-connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // include 'db-connect.php';
    // $username = $_POST["username"];
    $username = preg_replace("/[^a-zA-Z0-9]+/", "", $_POST["username"]);
    
    $password = $_POST["password"];

    // $name = $_POST["name"];
    $name = preg_replace("/[^a-zA-Z0-9]\s+/", "", $_POST["name"]);

    // $emp_id = $_POST["empid"];
    $emp_id = preg_replace("/[^a-zA-Z0-9]+/", "", $_POST["empid"]);

    $usertype = 2; // 2 = Employee, 1 = Admin

    if ($password != "" && $username != "" && $usertype > 0 && $usertype < 3
        && $name != "" && $emp_id != "") {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $query = "INSERT INTO `users` (`usertype`, `name`, `emp_id`, `username`, `password_hash`) 
        VALUES ('$usertype', '$name', '$emp_id', '$username', '$password_hash')";
        $result = mysqli_query($conn, $query);

        echo "Employee Added Succesfully! Username: ".$username." Password : ".$password;
        ?>
        <script>
            window.location = "dashboard.php";
        </script>
        <?php
    }
    else {
        echo "Couldn't signup!<br>Make sure that you have entered all the fields correctly.";
    }

}


?><html>
    <head>
        <title>Add Employee</title>
      </head>

      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<body>
<!-- include nav.php -->


<style>
    button.addemployeebutton {
                background-color: #333;
                color: #fff;
                border: none;
                border-radius: 6px;
                font-size: 20px;
                line-height: 48px;
                padding: 0 16px;
                width: 332px;
                cursor: pointer;
                display: block;
                margin: 20 auto;
            }
    button.addemployeebutton:hover {
        background-color: #111;
    }
</style>

            
        <div>
            <?php include 'nav.php'; ?>

            <div><h1 style="margin:10px auto; display: block; width: fit-content;">Add New Employee<h1></div>
            <div>
                <form action="" method="post" action="" method="post" style="border: 1px solid black; margin:0 auto; width: fit-content; padding: 20px;">
                    <div style="padding: 10px;">
                        <div style="display: inline-block; width: 100px;">Name</div>
                        <input type="text" name="name" style="width: 300px; height: 10px; padding: 15px;">
                    </div>
                    <div style="padding: 10px;">
                        <div style="display: inline-block; width: 100px;">Employee ID</div>
                        <input type="text" name="empid" style="width: 300px; height: 10px; padding: 15px;">
                    </div>
                    <div style="padding: 10px;">
                        <div style="display: inline-block; width: 100px;">Username</div>
                        <input type="text" name="username" style="width: 300px; height: 10px; padding: 15px;">
                    </div>
                    <div style="padding: 10px;">
                        <div style="display: inline-block; width: 100px;">Password</div>
                        <input type="text" name="password" style="width: 300px; height: 10px; padding: 15px;">
                    </div>
                    <!--button>Add</button-->
                    <!--button type="submit"style="margin: 0 auto; display: block; padding: 10px; padding-left: 20px; padding-right: 20px;">Add Employee</button-->
                    
                        <button class="addemployeebutton" type="submit">Add Employee</button>
                    
                </form>
            </div>
        </div>
    
    
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
        <script src="extensions/natural-sorting/bootstrap-table-natural-sorting.js"></script>
    </body>
</html>
