-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 02, 2022 at 12:15 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `activeemp`
--

-- --------------------------------------------------------

--
-- Table structure for table `activeemp`
--

CREATE TABLE `activeemp` (
  `empid` int(3) NOT NULL,
  `empname` text NOT NULL,
  `empage` int(2) NOT NULL,
  `empsalary` int(11) NOT NULL,
  `joiningdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activeemp`
--

INSERT INTO `activeemp` (`empid`, `empname`, `empage`, `empsalary`, `joiningdate`) VALUES
(23, '2safdfdsaf', 33, 10210, '2014-12-24'),
(28, 'ssshgjyob', 91, 647000, '2019-12-09'),
(92, 'sshgjyob', 29, 627000, '2010-12-09'),
(98, 'hgjyob', 9, 67000, '2020-12-09'),
(244, 'dsagsdfg', 33, 122, '2022-11-21'),
(918, 'hgdjyob', 93, 673000, '2020-11-09'),
(928, 'hgjddyob', 29, 670200, '2020-02-09'),
(938, 'hgjyodb', 91, 670020, '2001-12-19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `usertype` int(1) NOT NULL,
  `name` varchar(128) NOT NULL,
  `emp_id` varchar(60) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password_hash` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usertype`, `name`, `emp_id`, `username`, `password_hash`) VALUES
(1, 'admin', '1', 'admin', '$2y$10$ASP7zI.BakHckJ5Q5D9Ki.8Fp4kwRxc8FzQW3YWZs7tVeMtH428su');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activeemp`
--
ALTER TABLE `activeemp`
  ADD UNIQUE KEY `empid` (`empid`),
  ADD UNIQUE KEY `empid_2` (`empid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
